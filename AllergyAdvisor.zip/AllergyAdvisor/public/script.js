document.getElementById("allergy-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const allergyInput = document.getElementById("allergy-input").value;
  
    const safeFoods = ["Apples", "Rice", "Chicken", "Carrots"];
    const avoidFoods = ["Nuts", "Dairy", "Gluten"];
  
    const resultsTable = document.getElementById("results");
    const resultsSection = document.getElementById("results-section");
  
    resultsTable.innerHTML = `
      <tr>
        <td class="safe">${safeFoods.join(", ")}</td>
        <td class="avoid">${avoidFoods.join(", ")}</td>
      </tr>
    `;
  
    resultsSection.classList.remove("hidden");
  });
  
  const themeToggle = document.getElementById("theme-toggle");
  themeToggle.addEventListener("click", () => {
    const currentTheme = document.body.getAttribute("data-theme");
    const newTheme = currentTheme === "dark" ? "light" : "dark";
    document.body.setAttribute("data-theme", newTheme);
  });
  